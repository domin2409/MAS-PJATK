public abstract class Pet {
    String name;

    public String getName() {
        return name;
    }
}
