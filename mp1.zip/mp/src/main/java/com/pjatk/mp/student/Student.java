package com.pjatk.mp.student;

import com.pjatk.mp.Feedback;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class Student {
    private static long nextId = 1;
    private long id;
    private String name;
    private String email;
    private LocalDate whenBorn;
    private Integer age;

    private List<Feedback> feedbacksRecieved; //complex, multi value attribute, one to many association
    private Optional<String> phone;


    public Student() {
        addStudent(this);
    }
    private static List<Student> extent = new ArrayList<>();
    private static void addStudent(Student student) {
        extent.add(student);
    }

    private String showFeedbacks(){
        return this.feedbacksRecieved.toString();
    }

    public Student(String name, String email, LocalDate whenBorn, Integer age, List<Feedback> feedbacksRecieved, Optional<String> phone) {
        nextId = nextId++;
        this.id = nextId;
        this.name = name;
        this.email = email;
        this.whenBorn = whenBorn;
        this.age = age;
        this.feedbacksRecieved = feedbacksRecieved;
        this.phone = phone;
    }

    public static void showExtent() {

        System.out.println("Extent of the class: " + Student.class.getName());

        for (Student student : extent) {
            System.out.println(student);
        }
    }

    @Override
    public String toString() {
        return "Student{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", email='" + email + '\'' +
                ", whenBorn=" + whenBorn +
                ", age=" + age +
                ", feedbacksGiven=" + feedbacksRecieved +
                ", average mark=" + this.getAvgRating() +
                ", phone=" + phone +
                '}';
    }
    public float getAvgRating() {
        int sum = 0;
        for (Feedback feedback : this.feedbacksRecieved) {
            sum += feedback.getRating();
        }
        return (float) sum / this.feedbacksRecieved.size();
    }
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public LocalDate getWhenBorn() {
        return whenBorn;
    }

    public void setWhenBorn(LocalDate whenBorn) {
        this.whenBorn = whenBorn;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public List<Feedback> getFeedbacksRecieved() {
        return feedbacksRecieved;
    }

    public void setFeedbacksRecieved(List<Feedback> feedbacksRecieved) {
        this.feedbacksRecieved = feedbacksRecieved;
    }

    public Optional<String> getPhone() {
        return phone;
    }

    public void setPhone(Optional<String> phone) {
        this.phone = phone;
    }

    public static List<Student> getExtent() {
        return extent;
    }

    public static void setExtent(List<Student> extent) {
        Student.extent = extent;
    }

    }
