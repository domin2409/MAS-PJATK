package com.pjatk.mp.student;

import com.pjatk.mp.Feedback;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;

import java.time.LocalDate;
import java.time.Month;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

@Service
public class StudentService {
    public List<Student> getStudents() {
        return List.of(
                new Student(

                        "Diane",
                        "diane@malpa.com",
                        LocalDate.of(1999, Month.APRIL, 1),
                        69,
                        Arrays.asList(
                                new Feedback("Ambitious, but stupid", 3),
                                new Feedback("Class clown", 2)),
                        Optional.empty()
                ),
                new Student(

                        "Dominik",
                        "dominik@malpa.com",
                        LocalDate.of(1999, Month.APRIL, 1),
                        69,
                        Arrays.asList(
                                new Feedback("Exceptional", 5),
                                new Feedback("Already miss him", 6)),
                        Optional.empty()
                )
        );
    }
}
