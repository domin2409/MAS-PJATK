package org.example;

public interface IBoat {
    public abstract double GetDraft();
    public abstract String GetHullType();
    public abstract void sail();
}
